package com.cg.ibs.loanmgmt.repositories;

import com.cg.ibs.loanmgmt.models.BankAdmins;

public interface BankAdminsDao {
	BankAdmins getAdminByUserId(String userId);
}

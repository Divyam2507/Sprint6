package com.cg.ibs.loanmgmt.models;

public enum LoanStatus {
	PENDING, SENT_FOR_VERIFICATION, APPROVED, DENIED, PRE_CLOSURE_VERIFICATION, PRE_CLOSED, CLOSED;

}

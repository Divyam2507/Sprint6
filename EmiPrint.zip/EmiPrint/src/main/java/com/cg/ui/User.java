package com.cg.ui;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.model.CustomerBean;
import com.cg.service.CustomerService;

public class User {
	@Autowired
	private static CustomerService customerService;
	
	private static Scanner read = new Scanner(System.in);
	private static CustomerBean customerBean = new CustomerBean();

	public static void main(String[] args) {
		boolean shallContinue = true;
		
		System.out.println("Enter cus");
		while (shallContinue) {
			System.out.println("Enter the Loan Amount");
			String loanAmountInput = read.next();
			Pattern pattern = Pattern.compile("[0-9]{1,50}");
			Matcher matcher = pattern.matcher(loanAmountInput);
			if (matcher.matches()) {
				BigDecimal loanAmount = new BigDecimal(loanAmountInput);
				customerBean.setLoanAmount(loanAmount);
				shallContinue = false;
			} else {
				System.out.println("**Please enter an appropriate numeric value!**");
			}
		}
		shallContinue = true;
		while (shallContinue) {
			System.out.println("Enter Loan Tenure (Months): ");
			String loanTenureInput = read.next();
			Pattern pattern = Pattern.compile("[0-9]{1,50}");
			Matcher matcher = pattern.matcher(loanTenureInput);
			if (matcher.matches()) {
				Integer loanTenure = new Integer(loanTenureInput);
				customerBean.setLoanTenure(loanTenure);
				customerBean.setBalance(customerBean.getLoanAmount());
				shallContinue = false;
			} else {
				System.out.println("**Please enter an appropriate numeric value!**");
			}
		}
		System.out.println(customerBean);
		customerService.addCustomer(customerBean);
		customerService.calculateEmi(customerBean);
		System.out.println("\nMonthly EMI: INR " + customerBean.getEmiAmount().toPlainString());
		System.out.printf("%20s %20s %20s", "EMI", "Interest", "Principle");
		System.out.println();
		for (int i = 0; i <= customerBean.getLoanTenure(); i++) {
			BigDecimal interest = customerService.calculatePaidInterest(customerBean).setScale(4,RoundingMode.HALF_UP);
			BigDecimal principle = customerService.calculatePaidPrinciple(customerBean, interest).setScale(4,RoundingMode.HALF_UP);
			System.out.println();
			System.out.format("%20f %20f %20f", customerBean.getEmiAmount(), interest, principle);
			System.out.println();
			customerBean.setBalance(customerBean.getBalance().subtract(principle).setScale(4,RoundingMode.HALF_UP));
		}
	}

}

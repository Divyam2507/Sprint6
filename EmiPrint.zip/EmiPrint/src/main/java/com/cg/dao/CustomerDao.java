package com.cg.dao;

import com.cg.model.CustomerBean;

public interface CustomerDao {
void addCustomer(CustomerBean customer);
}
package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.model.CustomerBean;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	@PersistenceContext
	private EntityManager entityManager;
	
	public void addCustomer(CustomerBean customer) {
		entityManager.persist(customer);
		
	}
	
}

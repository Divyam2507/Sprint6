package com.cg.service;

import java.math.BigDecimal;

import com.cg.model.CustomerBean;

public interface CustomerService {

	public BigDecimal calculateEmi(CustomerBean customerBean);

	public BigDecimal calculatePaidInterest(CustomerBean customerBean);

	public BigDecimal calculatePaidPrinciple(CustomerBean customerBean, BigDecimal interest);
	public void addCustomer(CustomerBean customer);
}

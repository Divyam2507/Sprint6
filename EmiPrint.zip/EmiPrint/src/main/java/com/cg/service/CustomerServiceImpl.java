package com.cg.service;

import java.math.BigDecimal;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CustomerDao;
import com.cg.model.CustomerBean;
@Service
public class CustomerServiceImpl implements CustomerService {
	CustomerBean customerBean = new CustomerBean();
	Float interestRate = 10.0f;
	@Autowired
	private CustomerDao customerDao;

	public BigDecimal calculateEmi(CustomerBean customerBean) {
		Float rate = interestRate / (12.0f * 100.0f);
		Double onePlusRPoweredN = Math.pow((rate + 1), customerBean.getLoanTenure());
		BigDecimal principal = customerBean.getLoanAmount();
		BigDecimal emi = principal.multiply(BigDecimal.valueOf((rate * onePlusRPoweredN) / (onePlusRPoweredN - 1)));
		return emi;
	}

	public BigDecimal calculatePaidInterest(CustomerBean customerBean) {
		BigDecimal Balance = customerBean.getBalance();
		Float rate = (interestRate / 100.0f);
		BigDecimal paidInterest = (Balance.multiply(BigDecimal.valueOf((Math.pow(1 + rate, 1.0 / 12.0)))))
				.subtract(Balance);
		return paidInterest;
	}

	public BigDecimal calculatePaidPrinciple(CustomerBean customerBean, BigDecimal interest) {

		BigDecimal paidPrinciple = customerBean.getEmiAmount().subtract(interest);
		return paidPrinciple;
	}
	@Transactional
	public void addCustomer(CustomerBean customer){
		customerDao.addCustomer(customer);
	}

}

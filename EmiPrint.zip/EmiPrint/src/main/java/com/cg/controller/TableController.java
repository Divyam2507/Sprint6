package com.cg.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.CustomerBean;
import com.cg.service.CustomerService;

@Controller
@RequestMapping("/")
public class TableController {
	@Autowired
	private CustomerService customerService;
	CustomerBean customer = new CustomerBean();

	@RequestMapping("/")
	private String home() {
		return "index";
	}

	@RequestMapping("/getloan")
	private String getLoanPage() {
		return "getLoan";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/SUBMIT")
	public ModelAndView sum(@RequestParam("customerId") Integer customerId,
			@RequestParam("loanAmount") BigDecimal loanAmount, @RequestParam("loanTenure") Integer loanTenure) {
		customer.setCustomerId(customerId);
		customer.setLoanAmount(loanAmount);
		customer.setLoanTenure(loanTenure);
		customer.setBalance(loanAmount);
		System.out.println(customer.getLoanAmount());
		BigDecimal Emi = customerService.calculateEmi(customer);
		customer.setEmiAmount(Emi);
		customerService.addCustomer(customer);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("message",customer.getEmiAmount());
		modelAndView.setViewName("showMessage");
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/customerOptions")
	private String getCustomerOptionsPage() {
		return getCustomerOptionsPage();
	}

}
